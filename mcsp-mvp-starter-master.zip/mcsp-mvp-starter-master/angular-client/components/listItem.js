angular.module('app')
.component('listItem', {
  bindings: {
    item: '<',
  },
  controller: function() {},
  templateUrl: '/templates/list-item.html'
});