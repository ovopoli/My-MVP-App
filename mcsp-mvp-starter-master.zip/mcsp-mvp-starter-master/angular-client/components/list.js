angular.module('app')
.component('list', {
  bindings: {
    items: '<',
  },
  controller: function() {},
  templateUrl: '/templates/list.html'
});